// Paul Robinson
// robinsop
// CS362-400 Summer 2018
// Assignment 3
// unittest2 - isGameOver


// pieces take from the provided testUpdateCoins sample
#include "dominion.h"
#include "dominion_helpers.h"
#include <string.h>
#include <stdio.h>



int myAssert(int expected, int actual){
  if (expected == actual){
    printf("TEST PASSED\n");
    return 0;
  }
  else {
    printf("Expected %d, actual %d, TEST FAILED!!!!!!\n", expected, actual);
    return 1;
  }
}

int main(){

  int seed = 1000;
  int numPlayer = 2;
  int r;
  int k[10] = {adventurer, council_room, feast, gardens, mine
          , remodel, smithy, village, baron, great_hall};
  struct gameState G;


  memset(&G, 23, sizeof(struct gameState));   // clear the game state
  r = initializeGame(numPlayer, k, seed, &G); // initialize a new game


  printf("Test if game is over at start of game with no changes\n");
  myAssert(0, isGameOver(&G));

  printf("Test if game is over with Provinces emptied\n");
  G.supplyCount[3] = 0;
  myAssert(1, isGameOver(&G));
  G.supplyCount[3] = 10;

  printf("Test if game is over with 2 non-Province piles emptied\n");
  G.supplyCount[2] = 0;
  G.supplyCount[4] = 0;
  myAssert(0, isGameOver(&G));

  printf("Test if game is over with 3 non-Province piles emptied\n");
  G.supplyCount[5] = 0;
  myAssert(1, isGameOver(&G));

  return 0;
}