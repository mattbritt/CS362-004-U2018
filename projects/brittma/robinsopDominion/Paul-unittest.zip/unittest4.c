// Paul Robinson
// robinsop
// CS362-400 Summer 2018
// Assignment 3
// unittest4 - scoreFor


#include "dominion.h"
#include "dominion_helpers.h"
#include <string.h>
#include <stdio.h>


int myAssert(int expected, int actual){
  if (expected == actual){
    printf("TEST PASSED\n");
    return 0;
  }
  else {
    printf("Expected %d, actual %d, TEST FAILED!!!!!!\n", expected, actual);
    return 1;
  }
}

int main(){

//  int i;
//  int j;
  int seed = 1000;
  int numPlayer = 2;
  int r;
  int k[10] = {adventurer, council_room, feast, gardens, mine
          , remodel, smithy, village, baron, great_hall};
  struct gameState G;

  memset(&G, 23, sizeof(struct gameState));   // clear the game state
  r = initializeGame(numPlayer, k, seed, &G); // initialize a new game

  printf("Test score at beginning of game is 3\n");
  printf("player 0 has %d estates\n", fullDeckCount(0, estate, &G));
  myAssert(3, scoreFor(0, &G));

  printf("Test 2 of each scoring card in hand, none in discard or deck\n");
  G.discardCount[0] = 0;
  G.deckCount[0] = 0;
  G.handCount[0] = 12;
  G.hand[0][0] = curse;
  G.hand[0][1] = curse;
  G.hand[0][2] = estate;
  G.hand[0][3] = estate;
  G.hand[0][4] = duchy;
  G.hand[0][5] = duchy;
  G.hand[0][6] = province;
  G.hand[0][7] = province;
  G.hand[0][8] = great_hall;
  G.hand[0][9] = great_hall;
  G.hand[0][10] = gardens;
  G.hand[0][11] = gardens;
  myAssert(22, scoreFor(0, &G));

  printf("Test 2 of each scoring card in discard, none in hand or deck\n");
  G.discardCount[0] = 12;
  G.deckCount[0] = 0;
  G.handCount[0] = 0;
  G.discard[0][0] = curse;
  G.discard[0][1] = curse;
  G.discard[0][2] = estate;
  G.discard[0][3] = estate;
  G.discard[0][4] = duchy;
  G.discard[0][5] = duchy;
  G.discard[0][6] = province;
  G.discard[0][7] = province;
  G.discard[0][8] = great_hall;
  G.discard[0][9] = great_hall;
  G.discard[0][10] = gardens;
  G.discard[0][11] = gardens;
  myAssert(22, scoreFor(0, &G));

  printf("Test 2 of each scoring card in deck, none in hand or discard\n");
  G.discardCount[0] = 0;
  G.deckCount[0] = 12;
  G.handCount[0] = 0;
  G.deck[0][0] = curse;
  G.deck[0][1] = curse;
  G.deck[0][2] = estate;
  G.deck[0][3] = estate;
  G.deck[0][4] = duchy;
  G.deck[0][5] = duchy;
  G.deck[0][6] = province;
  G.deck[0][7] = province;
  G.deck[0][8] = great_hall;
  G.deck[0][9] = great_hall;
  G.deck[0][10] = gardens;
  G.deck[0][11] = gardens;
  myAssert(22, scoreFor(0, &G));

  printf("Test 2 of each scoring card in hand except gardens, none in discard or deck\n");
  G.discardCount[0] = 0;
  G.deckCount[0] = 0;
  G.handCount[0] = 10;
  G.hand[0][0] = curse;
  G.hand[0][1] = curse;
  G.hand[0][2] = estate;
  G.hand[0][3] = estate;
  G.hand[0][4] = duchy;
  G.hand[0][5] = duchy;
  G.hand[0][6] = province;
  G.hand[0][7] = province;
  G.hand[0][8] = great_hall;
  G.hand[0][9] = great_hall;
  myAssert(20, scoreFor(0, &G));

  printf("Test 2 of each scoring card in discard except gardens, none in hand or deck\n");
  G.discardCount[0] = 10;
  G.deckCount[0] = 0;
  G.handCount[0] = 0;
  G.discard[0][0] = curse;
  G.discard[0][1] = curse;
  G.discard[0][2] = estate;
  G.discard[0][3] = estate;
  G.discard[0][4] = duchy;
  G.discard[0][5] = duchy;
  G.discard[0][6] = province;
  G.discard[0][7] = province;
  G.discard[0][8] = great_hall;
  G.discard[0][9] = great_hall;
  myAssert(20, scoreFor(0, &G));

  printf("Test 2 of each scoring card in deck except gardens, none in hand or discard\n");
  G.discardCount[0] = 0;
  G.deckCount[0] = 10;
  G.handCount[0] = 0;
  G.deck[0][0] = curse;
  G.deck[0][1] = curse;
  G.deck[0][2] = estate;
  G.deck[0][3] = estate;
  G.deck[0][4] = duchy;
  G.deck[0][5] = duchy;
  G.deck[0][6] = province;
  G.deck[0][7] = province;
  G.deck[0][8] = great_hall;
  G.deck[0][9] = great_hall;
  myAssert(20, scoreFor(0, &G));
  return 0;
}