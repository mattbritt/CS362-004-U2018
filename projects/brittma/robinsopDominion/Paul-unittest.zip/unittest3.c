// Paul Robinson
// robinsop
// CS362-400 Summer 2018
// Assignment 3
// unittest3 - fullDeckCount


#include "dominion.h"
#include "dominion_helpers.h"
#include <string.h>
#include <stdio.h>

// pieces take from the provided testUpdateCoins sample

int myAssert(int expected, int actual){
  if (expected == actual){
    printf("TEST PASSED\n");
    return 0;
  }
  else {
    printf("Expected %d, actual %d, TEST FAILED!!!!!!\n", expected, actual);
    return 1;
  }
}

int main(){

  int i;
  int j;
  int seed = 1000;
  int numPlayer = 2;
  int r;
  int k[10] = {adventurer, council_room, feast, gardens, mine
          , remodel, smithy, village, baron, great_hall};
  struct gameState G;


  memset(&G, 23, sizeof(struct gameState));   // clear the game state
  r = initializeGame(numPlayer, k, seed, &G); // initialize a new game


  printf("Test starting deck contains 3 estates and 7 coppers\n");
  myAssert(3, fullDeckCount(0, estate, &G));
  myAssert(7, fullDeckCount(0, copper, &G));

  printf("Test starting deck contains total of 10 cards\n");
  j = 0;
  for (i = 0; i < 27; i++){
    j += (fullDeckCount(0, i, &G));
  }
  myAssert(10, j);


  printf("Set deck, hand, and discard cards to -1 (invalid card), test equals 0\n");
  for (i = 0; i < 27; i++){
    G.deck[0][i] = -1;
    G.hand[0][i] = -1;
    G.discard[0][i] = -1;
  }

  j = 0;
  for (i = 0; i < 27; i++){
    j += (fullDeckCount(0, i, &G));
  }
  myAssert(0, j);

  printf("Set deck, hand, and discard cards to hold 27 cards each, test equals 81\n");
  G.handCount[0] = 27;
  G.deckCount[0] = 27;
  G.discardCount[0] = 27;
  for (i = 0; i < 27; i++){
    G.deck[0][i] = 1;
    G.hand[0][i] = 1;
    G.discard[0][i] = 1;
  }
  j = 0;
  for (i = 0; i < 27; i++){
    j += (fullDeckCount(0, i, &G));
  }
  myAssert(81, j);

  return 0;
}

