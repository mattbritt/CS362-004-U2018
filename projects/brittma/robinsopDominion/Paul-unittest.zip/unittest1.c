// Paul Robinson
// robinsop
// CS362-400 Summer 2018
// Assignment 3
// unittest1 buyCard

// pieces take from the provided testUpdateCoins sample
#include "dominion.h"
#include "dominion_helpers.h"
#include <string.h>
#include <stdio.h>


int myAssert(int expected, int actual){
  if (expected == actual){
    printf("TEST PASSED\n");
    return 0;
  }
  else {
    printf("Expected %d, actual %d, TEST FAILED!!!!!!\n", expected, actual);
    return 1;
  }
}

int main(){

  int seed = 1000;
  int numPlayer = 2;
  int r;
  int k[10] = {adventurer, council_room, feast, gardens, mine
          , remodel, smithy, village, baron, great_hall};
  struct gameState G;


  memset(&G, 23, sizeof(struct gameState));   // clear the game state
  r = initializeGame(numPlayer, k, seed, &G); // initialize a new game


  printf("Test purchase with no buys left\n");
  G.numBuys = 0;
  myAssert(-1, buyCard(0, &G));
  G.numBuys = 10;

  printf("Test purchase of card that has 0 supply left\n");
  G.supplyCount[1] = 0;
  myAssert(-1, buyCard(1, &G));
  G.supplyCount[1] = 10;

  printf("Test purchase of a cost 5 card with 4 coins\n");
  G.coins = 4;
  myAssert(-1, buyCard(2, &G));

  printf("Test purchase of card with cost 3, having 4 coins\n");
  G.coins = 4;
  myAssert(0, buyCard(5, &G));



  return 0;
}