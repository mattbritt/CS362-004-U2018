// Paul Robinson
// robinsop
// CS362-400 Summer 2018
// Assignment 3
// cardtest3 - Village

#include "dominion.h"
#include "dominion_helpers.h"
#include <string.h>
#include <stdio.h>

int myAssert(int expected, int actual){
  if (expected == actual){
    printf("TEST PASSED\n");
    return 0;
  }
  else {
    printf("Expected %d, actual %d, TEST FAILED!!!!!!\n", expected, actual);
    return 1;
  }
}

int main(){

  int actions;
  int seed = 1000;
  int numPlayer = 2;
  int r;
  int k[10] = {adventurer, council_room, feast, gardens, mine
          , remodel, smithy, village, baron, great_hall};
  struct gameState G;
  int bonus;

  memset(&G, 23, sizeof(struct gameState));   // clear the game state
  r = initializeGame(numPlayer, k, seed, &G); // initialize a new game

  G.hand[0][0] = village; // put a village in player's hand at pos 0
  printf("Test Village effect\n");

  actions = G.numActions;
  cardEffect(village, 0, 0, 0, &G, 0, &bonus);

  printf("Test extra card in hand\n");
  myAssert(5, G.handCount[0]);
  printf("Test numActions increased by 2 after playing Village\n");
  myAssert(actions + 2, G.numActions);


  return 0;
}
