// Paul Robinson
// robinsop
// CS362-400 Summer 2018
// Assignment 3
// cardtest4 - Outpost


#include "dominion.h"
#include "dominion_helpers.h"
#include <string.h>
#include <stdio.h>



int myAssert(int expected, int actual){
  if (expected == actual){
    printf("TEST PASSED\n");
    return 0;
  }
  else {
    printf("Expected %d, actual %d, TEST FAILED!!!!!!\n", expected, actual);
    return 1;
  }
}

int main(){

  int seed = 1000;
  int numPlayer = 2;
  int r;
  int k[10] = {adventurer, council_room, feast, gardens, mine
          , remodel, smithy, village, baron, outpost};
  struct gameState G;
  int bonus;

  memset(&G, 23, sizeof(struct gameState));   // clear the game state
  r = initializeGame(numPlayer, k, seed, &G); // initialize a new game

  G.hand[0][0] = outpost; // put an outpost in player's hand at pos 0
  printf("Test Outpost effect\n");
  printf("Test Outpost flag before play\n");
  myAssert(0, G.outpostPlayed);
  cardEffect(outpost, 0, 0, 0, &G, 0, &bonus);
  printf("Test Outpost flag after play\n");
  myAssert(1, G.outpostPlayed);


  return 0;
}
