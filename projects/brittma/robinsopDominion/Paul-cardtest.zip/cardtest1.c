// Paul Robinson
// robinsop
// CS362-400 Summer 2018
// Assignment 3
// cardtest1 - adventurer


#include "dominion.h"
#include "dominion_helpers.h"
#include <string.h>
#include <stdio.h>

int myAssert(int expected, int actual){
  if (expected == actual){
    printf("TEST PASSED\n");
    return 0;
  }
  else {
    printf("Expected %d, actual %d, TEST FAILED!!!!!!\n", expected, actual);
    return 1;
  }
}

int main(){

  int seed = 1000;
  int numPlayer = 2;
  int r;
  int k[10] = {adventurer, council_room, feast, gardens, mine
          , remodel, smithy, village, baron, great_hall};
  struct gameState G;
  int bonus;

  memset(&G, 23, sizeof(struct gameState));   // clear the game state
  r = initializeGame(numPlayer, k, seed, &G); // initialize a new game

  G.hand[0][0] = adventurer; // put an adventurer in player's hand at pos 0
  printf("Test that Adventurer adds 2 treasure cards to your hand\n");
  printf("Test hand count\n");
  cardEffect(adventurer, 0, 0, 0, &G, 0, &bonus);
  myAssert(6, G.handCount[0]);



  return 0;
}